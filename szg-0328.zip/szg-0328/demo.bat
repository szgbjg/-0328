@echo off
setlocal
chcp 65001 >nul

cd /d %~dp0

echo ========================================
echo Medical QA Demo - One Click Runner
echo ========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python not found in PATH.
  goto :fail
)

echo [1/5] Running unit tests...
python -m pytest tests/unit -q
if errorlevel 1 goto :fail
echo.

echo [2/5] Running validators tests...
python -m pytest tests/validators -q
if errorlevel 1 goto :fail
echo.

echo [3/5] Quick agent function check...
python -c "import asyncio; from src.agents.facet_qa_agent import FacetQAAgent; refs=[{'id':'R1','source':'《说明书》','content':'...'}]; model_call=lambda **kwargs: asyncio.sleep(0, '<think>\n<facet=临床安全>\n证据清单: [证据R1:来源=refs:《说明书》]\n</think>\n正文：说明书提示过敏者禁用。'); r=asyncio.run(FacetQAAgent().generate_facet_answer('阿司匹林禁忌','临床安全',refs,model_call)); print('quick_ok:', r is not None, 'evidence_count:', r['evidence_count'])"
if errorlevel 1 goto :fail
echo.

echo [4/5] End-to-end single round generation...
python -m src.cli generate_single --context "阿司匹林用于缓解疼痛，禁忌症包括过敏者" --output output/test_round.json
if errorlevel 1 goto :fail
echo.

echo [5/5] Inspect generated output + banned words scan...
type output\test_round.json
echo.
python -c "import json; from src.validators.content_guard import check_banned_words; d=json.load(open('output/test_round.json','r',encoding='utf-8')); hits=[]; [hits.extend(check_banned_words(a)) for a in d.get('facet_answers',[])]; print('禁用词命中:', hits)"
if errorlevel 1 goto :fail

echo.
echo ========================================
echo Demo completed successfully!
echo ========================================
goto :end

:fail
echo.
echo ========================================
echo Demo failed. Please check logs above.
echo ========================================

:end
echo.
pause
endlocal
